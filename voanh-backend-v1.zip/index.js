const express = require('express');
const { Client } = require('@notionhq/client');
const app = express();
const notion = new Client({ auth: 'YOUR_NOTION_TOKEN' });
const PAGE_ID = 'YOUR_NOTION_PAGE_ID';

app.get('/sync', async (req, res) => {
  const message = req.query.message || 'No message';
  try {
    await notion.pages.create({
      parent: { database_id: PAGE_ID },
      properties: {
        Name: {
          title: [{ text: { content: message } }]
        }
      }
    });
    res.send('✅ Ghi log thành công!');
  } catch (err) {
    console.error('❌ Lỗi ghi vào Notion:', err);
    res.status(500).send('Lỗi ghi vào Notion');
  }
});

app.listen(3000, () => {
  console.log('🚀 Server chạy tại http://localhost:3000');
});
